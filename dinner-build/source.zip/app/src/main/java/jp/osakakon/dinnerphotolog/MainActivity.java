package jp.osakakon.dinnerphotolog;

import android.app.Activity;
import android.Manifest;
import android.os.Build;
import android.content.pm.PackageManager;
import android.content.ContentUris;
import android.content.ContentResolver;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.app.DownloadManager;
import android.os.Environment;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import java.io.File;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.util.Size;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.exifinterface.media.ExifInterface;
import androidx.webkit.WebViewAssetLoader;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int SELECT_PHOTOS_REQUEST = 4201;
    private static final int SCAN_PHOTOS_REQUEST = 4202;
    private WebView webView;
    private long pendingDownloadId = -1L;
    private boolean installerPending = false;
    private final android.os.Handler updateHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private boolean updateCheckScheduled = false;
    private final Runnable updateCheck = new Runnable() {
        @Override public void run() {
            updateCheckScheduled = false;
            pollUpdateDownload();
        }
    };
    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) return;
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
            if (id != pendingDownloadId) return;
            pollUpdateDownload();
        }
    };
    private void showUpdateStatus(String message) {
        if (webView != null) {
            String quoted = JSONObject.quote(message);
            webView.evaluateJavascript("if(window.dinnerUpdateStatus)window.dinnerUpdateStatus(" + quoted + ")", null);
        }
    }
    private void scheduleUpdateCheck() {
        if (pendingDownloadId == -1 || updateCheckScheduled) return;
        updateCheckScheduled = true;
        updateHandler.postDelayed(updateCheck, 900);
    }
    private void pollUpdateDownload() {
        if (pendingDownloadId == -1) return;
        DownloadManager manager = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
        try (Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(pendingDownloadId))) {
            if (cursor == null || !cursor.moveToFirst()) {
                updateHandler.removeCallbacks(updateCheck);
                pendingDownloadId = -1L;
                getPreferences(MODE_PRIVATE).edit().remove("pending_apk_download").apply();
                showUpdateStatus("更新ファイルを確認できません。もう一度更新を押してください");
                return;
            }
            int status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            if (status == DownloadManager.STATUS_SUCCESSFUL) {
                pendingDownloadId = -1L;
                getPreferences(MODE_PRIVATE).edit().remove("pending_apk_download").apply();
                installerPending = false;
                showUpdateStatus("ダウンロード完了。更新ファイルを検証中…");
                installDownloadedUpdate();
                return;
            }
            if (status == DownloadManager.STATUS_FAILED) {
                int reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));
                pendingDownloadId = -1L;
                getPreferences(MODE_PRIVATE).edit().remove("pending_apk_download").apply();
                showUpdateStatus("ダウンロードに失敗しました（" + reason + "）。通信状態を確認してください");
                return;
            }
            long downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            showUpdateStatus(total > 0 ? "更新ファイルを取得中 " + Math.min(100, downloaded * 100 / total) + "%" : "更新ファイルを取得中…");
            scheduleUpdateCheck();
        } catch (Exception err) {
            showUpdateStatus("更新状態を確認中…");
            scheduleUpdateCheck();
        }
    }
    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
    private android.webkit.ValueCallback<Uri[]> chooserCallback;
    private final Map<String, String> capturedDates = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 15, 20));
        getWindow().setNavigationBarColor(Color.rgb(11, 15, 20));

        pendingDownloadId = getPreferences(MODE_PRIVATE).getLong("pending_apk_download", -1L);
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(downloadReceiver, filter);
        }
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 15, 20));
        webView.setPadding(0, 0, 0, 0);
        setContentView(webView);
        webView.setFitsSystemWindows(true);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // AssetLoader provides a real HTTPS origin for IndexedDB without external hosting.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/photo/", path -> {
                    try {
                        long photoId = Long.parseLong(path);
                        Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, photoId);
                        ContentResolver resolver = getContentResolver();
                        InputStream stream = resolver.openInputStream(uri);
                        if (stream == null) return null;
                        String mime = resolver.getType(uri);
                        return new WebResourceResponse(mime == null ? "image/jpeg" : mime, "UTF-8", stream);
                    } catch (Exception ignored) {
                        return null;
                    }
                })
                .addPathHandler("/thumb/", path -> {
                    try {
                        long photoId = Long.parseLong(path);
                        Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, photoId);
                        Bitmap image = getContentResolver().loadThumbnail(uri, new Size(180, 180), null);
                        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                        if (!image.compress(Bitmap.CompressFormat.JPEG, 70, bytes)) return null;
                        return new WebResourceResponse("image/jpeg", "UTF-8",
                                new ByteArrayInputStream(bytes.toByteArray()));
                    } catch (Exception ignored) {
                        return null;
                    }
                })
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("dinnerscan".equals(uri.getScheme())) { startDinnerScan(); return true; }
                if ("dinnerupdate".equals(uri.getScheme())) { openUpdatePage(); return true; }
                if ("appassets.androidplatform.net".equals(uri.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (Exception ignored) { }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView,
                    android.webkit.ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = filePathCallback;
                capturedDates.clear();
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                        fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivityForResult(intent, SELECT_PHOTOS_REQUEST);
                    return true;
                } catch (Exception error) {
                    chooserCallback = null;
                    filePathCallback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this,"写真を選べませんでした",Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        // A new APK must not serve stale HTML/CSS/JS from the previous WebView HTTP cache.
        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.clearCache(true);  // Cache only: IndexedDB/user photos are preserved.
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        scheduleUpdateCheck();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != SELECT_PHOTOS_REQUEST || chooserCallback == null) return;
        android.webkit.ValueCallback<Uri[]> callback = chooserCallback;
        chooserCallback = null;
        Uri[] selected = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                selected = new Uri[count];
                for (int i=0; i<count; i++) selected[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                selected = new Uri[]{data.getData()};
            }
        }
        if (selected != null) {
            for (Uri uri : selected) {
                collectPhotoDate(uri);
            }
        }
        callback.onReceiveValue(selected);
    }

    private void collectPhotoDate(Uri uri) {
        String name = null;
        long size = -1;
        String exifDate = null;
        String dateFromMedia = null;
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                int takenIndex = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN);
                if (nameIndex >= 0) name = cursor.getString(nameIndex);
                if (sizeIndex >= 0) size = cursor.getLong(sizeIndex);
                if (takenIndex >= 0 && !cursor.isNull(takenIndex)) {
                    long timestamp = cursor.getLong(takenIndex);
                    if (timestamp > 946684800000L)
                        dateFromMedia = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(timestamp));
                }
            }
        } catch (Exception ignored) { }
        try (InputStream stream = getContentResolver().openInputStream(uri)) {
            if (stream != null) {
                ExifInterface exif = new ExifInterface(stream);
                String raw = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL);
                if (raw == null) raw = exif.getAttribute(ExifInterface.TAG_DATETIME_DIGITIZED);
                if (raw == null) raw = exif.getAttribute(ExifInterface.TAG_DATETIME);
                if (raw != null && raw.matches("\\d{4}:\\d{2}:\\d{2}.*")) {
                    exifDate = raw.substring(0,10).replace(':','-');
                }
            }
        } catch (Exception ignored) { }
        String date = exifDate != null ? exifDate : dateFromMedia;
        if (date != null && name != null && size >= 0) capturedDates.put(name+"#"+size,date);
    }

    private void startDinnerScan() {
        String permission = Build.VERSION.SDK_INT >= 33 ?
                Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= 34) {
                requestPermissions(new String[] { Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED }, SCAN_PHOTOS_REQUEST);
            } else {
                requestPermissions(new String[] { permission }, SCAN_PHOTOS_REQUEST);
            }
            return;
        }
        new Thread(this::scanDinnerPhotos, "DinnerGalleryScan").start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != SCAN_PHOTOS_REQUEST) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            startDinnerScan();
        } else {
            runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onDinnerNativeError('写真へのアクセスが限定されています。設定からすべての写真を許可してください')",null));
        }
    }

    private void scanDinnerPhotos() {
        JSONArray matches = new JSONArray();
        int scanned = 0;
        int timeMatched = 0;
        try (Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[] { MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN,
                        MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DISPLAY_NAME,
                        MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.MIME_TYPE }, null, null,
                MediaStore.Images.Media.DATE_TAKEN + " DESC")) {
            if (cursor != null) {
                while(cursor.moveToNext() && matches.length() < 12000) {
                    scanned++;
                    String filename = cursor.getString(3);
                    String folder = cursor.getString(4);
                    String mime = cursor.getString(5);
                    String description = ((filename == null ? "" : filename) + " " +
                            (folder == null ? "" : folder)).toLowerCase(Locale.ROOT);
                    if (description.contains("screenshot") || description.contains("screen_shot") ||
                            description.contains("screen shot") || description.contains("screencap") ||
                            description.contains("screenrecord") || description.contains("screen_record") ||
                            description.contains("スクリーンショット") || description.contains("screenshots/") ||
                            description.contains("screen captures/") || description.contains("screen_capture") ||
                            description.contains("/downloads/") || description.contains("download/")) continue;
                    if (mime == null || !mime.startsWith("image/")) continue;
                    long ts = cursor.getLong(1);
                    if (ts <= 0) ts = cursor.getLong(2) * 1000L;
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTimeInMillis(ts);
                    int hour = calendar.get(Calendar.HOUR_OF_DAY);
                    if (hour < 0 || hour >= 24) continue; // Filter by user-selected time in app.js
                    timeMatched++;
                    JSONObject photo = new JSONObject();
                    photo.put("id", cursor.getLong(0));
                    photo.put("ts", ts);
                    matches.put(photo);
                }
            }
            JSONObject report = new JSONObject();
            report.put("items",matches);
            report.put("scanned",scanned);
            report.put("timeMatched",timeMatched);
            final String javascript = "window.onDinnerNativeScan("+report.toString()+")";
            runOnUiThread(() -> webView.evaluateJavascript(javascript,null));
        } catch (Exception ex) {
            runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onDinnerNativeError('写真フォルダの読み取りに失敗しました')",null));
        }
    }

    private void openUpdatePage() {
        if (pendingDownloadId != -1L) {
            showUpdateStatus("ダウンロード状態を確認しています…");
            pollUpdateDownload();
            return;
        }
        try {
            // Cache buster ensures GitHub's stable download path resolves the latest APK.
            Uri url = Uri.parse("https://raw.githubusercontent.com/osakakon-ai/fx-souba-yosou-update/main/dinner/Dinner-Photo-Log.apk?v=" + System.currentTimeMillis());
            File oldApk = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Dinner-Photo-Log-update.apk");
            if (oldApk.isFile() && !oldApk.delete()) {
                showUpdateStatus("保存済みの更新ファイルを削除できません。端末容量を確認してください");
                return;
            }
            DownloadManager.Request request = new DownloadManager.Request(url);
            request.setTitle("晩ごはん記録 更新");
            request.setDescription("最新版をダウンロードしています");
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "Dinner-Photo-Log-update.apk");
            DownloadManager manager = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
            pendingDownloadId = manager.enqueue(request);
            getPreferences(MODE_PRIVATE).edit().putLong("pending_apk_download", pendingDownloadId).apply();
            showUpdateStatus("ダウンロードを開始しました");
            scheduleUpdateCheck();
        } catch (Exception err) {
            pendingDownloadId = -1L;
            showUpdateStatus("更新を開始できませんでした: " + err.getClass().getSimpleName());
        }
    }

    private void installDownloadedUpdate() {
        try {
            File file = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Dinner-Photo-Log-update.apk");
            if (!file.isFile() || file.length() < 10000) {
                showMessage("更新ファイルが見つかりません");
                return;
            }
            android.content.pm.PackageInfo archived = getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(), 0);
            if (archived == null || !getPackageName().equals(archived.packageName)) {
                showMessage("更新ファイルが正しくありません");
                return;
            }
            long available = Build.VERSION.SDK_INT >= 28 ? archived.getLongVersionCode() : archived.versionCode;
            long installed = 0;
            try {
                android.content.pm.PackageInfo current = getPackageManager().getPackageInfo(getPackageName(), 0);
                installed = Build.VERSION.SDK_INT >= 28 ? current.getLongVersionCode() : current.versionCode;
            } catch (Exception ignored) { }
            if (available <= installed) {
                showUpdateStatus("すでに最新版です（v" + archived.versionName + "）。インストールは不要です");
                installerPending = false;
                return;
            }
            showMessage("新版 v" + archived.versionName + " のインストール確認へ進みます");
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                showUpdateStatus("インストール許可が必要です。許可後にインストール画面へ進みます");
                installerPending = true;
                Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                startActivity(settings);
                return;
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(uri, "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            installerPending = false;
            showUpdateStatus("Androidのインストール確認画面を開きます");
            startActivity(install);
        } catch (Exception err) {
            installerPending = false;
            showUpdateStatus("インストール画面を開けませんでした: " + err.getClass().getSimpleName());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (pendingDownloadId != -1L) scheduleUpdateCheck();
        if (installerPending && (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls())) {
            // Run after returning from the system's unknown-sources permission screen.
            new android.os.Handler(getMainLooper()).post(this::installDownloadedUpdate);
        }
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void scanDinnerPhotos() { runOnUiThread(MainActivity.this::startDinnerScan); }
        @JavascriptInterface
        public String photoDateFor(String name, String size) {
            String result = capturedDates.get(name+"#"+size);
            return result == null ? "" : result;
        }
        @JavascriptInterface
        public void refreshApp() {
            runOnUiThread(MainActivity.this::openUpdatePage);
        }
    }
    @Override
    protected void onDestroy() {
        updateHandler.removeCallbacks(updateCheck);
        try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) { }
        if(webView != null) { webView.removeJavascriptInterface("AndroidApp"); webView.destroy(); }
        super.onDestroy();
    }
}
