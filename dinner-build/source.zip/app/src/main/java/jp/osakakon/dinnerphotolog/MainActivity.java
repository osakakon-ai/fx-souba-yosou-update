package jp.osakakon.dinnerphotolog;

import android.app.Activity;
import android.Manifest;
import android.os.Build;
import android.content.pm.PackageManager;
import android.content.ContentUris;
import android.content.ContentResolver;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.app.DownloadManager;
import android.os.Environment;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import java.io.File;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.util.Size;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.exifinterface.media.ExifInterface;
import androidx.webkit.WebViewAssetLoader;

import java.io.InputStream;
import java.io.BufferedInputStream;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import java.io.IOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.LinkedHashSet;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int SELECT_PHOTOS_REQUEST = 4201;
    private static final int ZIP_ALBUM_REQUEST = 4203;
    private static final int SINGLE_PHOTO_REQUEST = 4204;
    private volatile boolean stopZipImport = false;
    private volatile boolean zipBusy = false;
    private final AtomicReference<CountDownLatch> zipAckLatch = new AtomicReference<>();
    private volatile String zipAckResponse = "";
    private static final int SCAN_PHOTOS_REQUEST = 4202;
    private WebView webView;
    private long pendingDownloadId = -1L;
    private boolean installerPending = false;
    private final android.os.Handler updateHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private boolean updateCheckScheduled = false;
    private final Runnable updateCheck = new Runnable() {
        @Override public void run() {
            updateCheckScheduled = false;
            pollUpdateDownload();
        }
    };
    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(intent.getAction())) return;
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
            if (id != pendingDownloadId) return;
            pollUpdateDownload();
        }
    };
    private void showUpdateStatus(String message) {
        if (webView != null) {
            String quoted = JSONObject.quote(message);
            webView.evaluateJavascript("if(window.dinnerUpdateStatus)window.dinnerUpdateStatus(" + quoted + ")", null);
        }
    }
    private void scheduleUpdateCheck() {
        if (pendingDownloadId == -1 || updateCheckScheduled) return;
        updateCheckScheduled = true;
        updateHandler.postDelayed(updateCheck, 900);
    }
    private void pollUpdateDownload() {
        if (pendingDownloadId == -1) return;
        DownloadManager manager = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
        try (Cursor cursor = manager.query(new DownloadManager.Query().setFilterById(pendingDownloadId))) {
            if (cursor == null || !cursor.moveToFirst()) {
                updateHandler.removeCallbacks(updateCheck);
                pendingDownloadId = -1L;
                getPreferences(MODE_PRIVATE).edit().remove("pending_apk_download").apply();
                showUpdateStatus("更新ファイルを確認できません。もう一度更新を押してください");
                return;
            }
            int status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            if (status == DownloadManager.STATUS_SUCCESSFUL) {
                pendingDownloadId = -1L;
                getPreferences(MODE_PRIVATE).edit().remove("pending_apk_download").apply();
                installerPending = false;
                showUpdateStatus("ダウンロード完了。更新ファイルを検証中…");
                installDownloadedUpdate();
                return;
            }
            if (status == DownloadManager.STATUS_FAILED) {
                int reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));
                pendingDownloadId = -1L;
                getPreferences(MODE_PRIVATE).edit().remove("pending_apk_download").apply();
                showUpdateStatus("ダウンロードに失敗しました（" + reason + "）。通信状態を確認してください");
                return;
            }
            long downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            showUpdateStatus(total > 0 ? "更新ファイルを取得中 " + Math.min(100, downloaded * 100 / total) + "%" : "更新ファイルを取得中…");
            scheduleUpdateCheck();
        } catch (Exception err) {
            showUpdateStatus("更新状態を確認中…");
            scheduleUpdateCheck();
        }
    }
    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
    private android.webkit.ValueCallback<Uri[]> chooserCallback;
    private final Map<String, String> capturedDates = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 15, 20));
        getWindow().setNavigationBarColor(Color.rgb(11, 15, 20));

        pendingDownloadId = getPreferences(MODE_PRIVATE).getLong("pending_apk_download", -1L);
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(downloadReceiver, filter);
        }
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 15, 20));
        webView.setPadding(0, 0, 0, 0);
        setContentView(webView);
        webView.setFitsSystemWindows(true);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // AssetLoader provides a real HTTPS origin for IndexedDB without external hosting.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/photo/", path -> {
                    try {
                        long photoId = Long.parseLong(path);
                        Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, photoId);
                        ContentResolver resolver = getContentResolver();
                        InputStream stream = resolver.openInputStream(uri);
                        if (stream == null) return null;
                        String mime = resolver.getType(uri);
                        return new WebResourceResponse(mime == null ? "image/jpeg" : mime, "UTF-8", stream);
                    } catch (Exception ignored) {
                        return null;
                    }
                })
                .addPathHandler("/thumb/", path -> {
                    try {
                        long photoId = Long.parseLong(path);
                        Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, photoId);
                        Bitmap image = getContentResolver().loadThumbnail(uri, new Size(180, 180), null);
                        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                        if (!image.compress(Bitmap.CompressFormat.JPEG, 70, bytes)) return null;
                        return new WebResourceResponse("image/jpeg", "UTF-8",
                                new ByteArrayInputStream(bytes.toByteArray()));
                    } catch (Exception ignored) {
                        return null;
                    }
                })
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("dinnerscan".equals(uri.getScheme())) { startDinnerScan(); return true; }
                if ("dinnerupdate".equals(uri.getScheme())) { openUpdatePage(); return true; }
                if ("appassets.androidplatform.net".equals(uri.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (Exception ignored) { }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView,
                    android.webkit.ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = filePathCallback;
                capturedDates.clear();
                // Android Photo Picker surfaces local + eligible Google Photos cloud albums.
                // ACTION_OPEN_DOCUMENT does not show the Google Photos album tab.
                Intent intent;
                boolean multiple = fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
                if (Build.VERSION.SDK_INT >= 33) {
                    intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
                    intent.setType("image/*");
                    if (multiple) {
                        // The platform can limit each batch; the user may repeat import.
                        int limit = MediaStore.getPickImagesMaxLimit();
                        if (limit > 1) intent.putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, limit);
                    }
                } else {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
                }
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivityForResult(intent, SELECT_PHOTOS_REQUEST);
                    return true;
                } catch (Exception error) {
                    chooserCallback = null;
                    filePathCallback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this,"写真を選べませんでした",Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        // A new APK must not serve stale HTML/CSS/JS from the previous WebView HTTP cache.
        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.clearCache(true);  // Cache only: IndexedDB/user photos are preserved.
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        scheduleUpdateCheck();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ZIP_ALBUM_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                new Thread(() -> importGoogleAlbumZip(uri), "DinnerGoogleAlbumZip").start();
            } else {
                zipStatus("取り込みをキャンセルしました");
            }
            return;
        }
        if (requestCode == SINGLE_PHOTO_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                final Uri picked = data.getData();
                new Thread(() -> deliverSinglePhoto(picked), "DinnerSinglePhoto").start();
            } else {
                singlePhotoError("写真の選択をキャンセルしました");
            }
            return;
        }
        if (requestCode != SELECT_PHOTOS_REQUEST || chooserCallback == null) return;
        android.webkit.ValueCallback<Uri[]> callback = chooserCallback;
        chooserCallback = null;
        if (resultCode != RESULT_OK || data == null) {
            callback.onReceiveValue(null);
            return;
        }
        // Avoid duplicate URIs and avoid blocking the main/UI thread while opening
        // multiple cloud-backed photos to read EXIF metadata.
        LinkedHashSet<Uri> unique = new LinkedHashSet<>();
        if (data.getClipData() != null) {
            int count = data.getClipData().getItemCount();
            for (int i = 0; i < count; i++) {
                Uri uri = data.getClipData().getItemAt(i).getUri();
                if (uri != null && "content".equals(uri.getScheme())) unique.add(uri);
            }
        }
        if (data.getData() != null && "content".equals(data.getData().getScheme())) {
            unique.add(data.getData());
        }
        if (unique.isEmpty()) {
            callback.onReceiveValue(null);
            return;
        }
        Uri[] selected = unique.toArray(new Uri[0]);
        // The selection screen may return cloud photos; metadata can require
        // network reads, so never process it synchronously on the UI thread.
        new Thread(() -> {
            for (Uri uri : selected) {
                try { collectPhotoDate(uri); } catch (Exception ignored) { }
            }
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                callback.onReceiveValue(selected);
            });
        }, "DinnerPickerMetadata").start();
    }

    // The single-photo path is intentionally independent from WebChromeClient.
    // A failure to deliver cloud provider file:// handles must not block dinner logging.
    private void openSinglePhotoPicker() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(Intent.createChooser(pick, "写真を1枚選ぶ"), SINGLE_PHOTO_REQUEST);
        } catch (Exception error) {
            singlePhotoError("写真を選ぶ画面を開けませんでした");
        }
    }
    private void singlePhotoError(String message) {
        runOnUiThread(() -> {
            if (webView != null && !isFinishing() && !isDestroyed())
                webView.evaluateJavascript("window.dinnerSinglePhotoError && window.dinnerSinglePhotoError(" +
                    JSONObject.quote(message) + ")", null);
        });
    }
    private void deliverSinglePhoto(Uri uri) {
        try {
            String photoName = "晩ごはん写真.jpg";
            try (Cursor cursor = getContentResolver().query(uri,
                    new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    String name = cursor.getString(0);
                    if (name != null && name.length() > 0) photoName = name;
                }
            } catch (Exception ignored) { }
            String date = "";
            try { collectPhotoDate(uri); } catch (Exception ignored) { }
            // The cloud provider's original bytes are read on a worker thread.
            // The OS may supply the photo locally or download the selected cloud item.
            byte[] original;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("写真を開けませんでした");
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[32768];int n;
                while ((n = in.read(buf)) != -1) {
                    if (out.size() + n > 48 * 1024 * 1024) throw new IOException("写真が大きすぎます（48MB超）");
                    out.write(buf,0,n);
                }
                original = out.toByteArray();
            }
            if (original.length == 0) throw new IOException("写真が空でした");
            date = zipFileDate(original);
            if (date.isEmpty()) {
                try (Cursor c = getContentResolver().query(uri,
                        new String[]{MediaStore.Images.Media.DATE_TAKEN},null,null,null)) {
                    if (c != null && c.moveToFirst() && !c.isNull(0)) {
                        long ms = c.getLong(0);
                        if (ms > 946684800000L) date = new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date(ms));
                    }
                } catch (Exception ignored) { }
            }
            byte[] jpeg = zipPhotoToJpeg(original);
            if (jpeg == null || jpeg.length == 0) throw new IOException("この写真形式を読み取れませんでした");
            final String sourceName = photoName;
            final String dateForJs = date;
            final String image = android.util.Base64.encodeToString(jpeg,android.util.Base64.NO_WRAP);
            runOnUiThread(() -> {
                if (webView == null || isFinishing() || isDestroyed()) return;
                webView.evaluateJavascript("window.dinnerSinglePhotoResult && window.dinnerSinglePhotoResult(" +
                    JSONObject.quote(sourceName) + "," + JSONObject.quote(image) + "," +
                    JSONObject.quote(dateForJs) + ")", null);
            });
        } catch (Exception ex) {
            singlePhotoError("写真を読み取れませんでした: " +
                (ex.getMessage() == null ? "写真へのアクセスを確認してください" : ex.getMessage()));
        }
    }

    private void zipStatus(String message) {
        runOnUiThread(() -> {
            if (webView != null && !isFinishing())
                webView.evaluateJavascript("window.dinnerZipStatus && window.dinnerZipStatus("+JSONObject.quote(message)+")",null);
        });
    }
    private void openAlbumZipPicker() {
        if (zipBusy) {zipStatus("すでに取り込み中です"); return;}
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("application/zip");
        pick.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip","application/x-zip-compressed","application/octet-stream"});
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(pick,ZIP_ALBUM_REQUEST); }
        catch(Exception err) {zipStatus("ZIPの選択画面を開けませんでした");}
    }
    private static boolean safeZipEntry(String name) {
        return name != null && !name.startsWith("/") && !name.startsWith("\\") &&
            !name.contains("../") && !name.contains("..\\") && !name.contains(":") && name.length()<350;
    }
    private static boolean photoZipEntry(String name) {
        String lower=name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") ||
               lower.endsWith(".webp") || lower.endsWith(".heic") || lower.endsWith(".heif");
    }
    private static String zipKey(String name) {
        if (name.endsWith(".supplemental-metadata.json")) return name.substring(0,name.length()-".supplemental-metadata.json".length());
        if (name.endsWith(".json")) return name.substring(0,name.length()-5);
        return name;
    }
    private static String takeoutPhotoDate(byte[] json) {
        try {
            JSONObject obj = new JSONObject(new String(json, java.nio.charset.StandardCharsets.UTF_8));
            JSONObject t=obj.optJSONObject("photoTakenTime");
            if(t==null)t=obj.optJSONObject("creationTime");
            if(t==null)return "";
            long seconds=Long.parseLong(t.optString("timestamp","0"));
            if(seconds<946684800L || seconds>4102444800L)return "";
            return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date(seconds*1000L));
        } catch(Exception ignored){return "";}
    }
    private static byte[] zipBytes(ZipInputStream zin,int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[65536]; int n;
        while((n=zin.read(buffer))!=-1) {
            if(out.size()+n > max)throw new IOException("展開サイズ超過");
            out.write(buffer,0,n);
        }
        return out.toByteArray();
    }
    private String zipFileDate(byte[] content) {
        try {
            ExifInterface exif = new ExifInterface(new ByteArrayInputStream(content));
            String raw=exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL);
            if(raw==null)raw=exif.getAttribute(ExifInterface.TAG_DATETIME);
            if(raw != null && raw.matches("\\d{4}:\\d{2}:\\d{2}.*"))
                return raw.substring(0,10).replace(':','-');
        } catch(Exception ignored){}
        return "";
    }
    private byte[] zipPhotoToJpeg(byte[] photo) {
        Bitmap bitmap = null; Bitmap scaled = null; Bitmap oriented = null;
        try {
            BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
            BitmapFactory.decodeByteArray(photo,0,photo.length,bounds);
            if(bounds.outWidth<=0 || bounds.outHeight<=0 || bounds.outWidth>25000 || bounds.outHeight>25000)return null;
            BitmapFactory.Options opt=new BitmapFactory.Options();opt.inSampleSize=1;
            while(Math.max(bounds.outWidth,bounds.outHeight)/opt.inSampleSize>2000)opt.inSampleSize*=2;
            bitmap=BitmapFactory.decodeByteArray(photo,0,photo.length,opt);
            if(bitmap==null)return null;
            int orientation=1;
            try{orientation=new ExifInterface(new ByteArrayInputStream(photo)).getAttributeInt(ExifInterface.TAG_ORIENTATION,1);}catch(Exception ignored){}
            Matrix matrix=new Matrix();
            if(orientation==3)matrix.postRotate(180);
            else if(orientation==6)matrix.postRotate(90);
            else if(orientation==8)matrix.postRotate(270);
            else if(orientation==2)matrix.postScale(-1,1);
            else if(orientation==4)matrix.postScale(1,-1);
            else if(orientation==5){matrix.postScale(-1,1);matrix.postRotate(90);}
            else if(orientation==7){matrix.postScale(-1,1);matrix.postRotate(270);}
            oriented=orientation==1?bitmap:Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
            int max=Math.max(oriented.getWidth(),oriented.getHeight());
            float ratio=Math.min(1.0f,1600f/max);
            scaled=ratio==1?oriented:Bitmap.createScaledBitmap(oriented,Math.max(1,Math.round(oriented.getWidth()*ratio)),Math.max(1,Math.round(oriented.getHeight()*ratio)),true);
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            if(!scaled.compress(Bitmap.CompressFormat.JPEG,79,out))return null;
            return out.toByteArray();
        }catch(Exception error){return null;}
        finally{
            if(scaled!=null && scaled!=bitmap && scaled!=oriented)scaled.recycle();
            if(oriented!=null && oriented!=bitmap)oriented.recycle();
            if(bitmap!=null)bitmap.recycle();
        }
    }
    private void importGoogleAlbumZip(Uri uri) {
        if(zipBusy)return;
        zipBusy=true;stopZipImport=false;
        int imported=0, skipped=0, total=0;
        try{
            // First pass reads only Takeout's JSON sidecars, so re-dated photos retain
            // their correct capture date. Source photos remain untouched.
            HashMap<String,String> metadata=new HashMap<>();
            boolean containsCookingFolder=false;
            int entries=0;
            try(InputStream input=getContentResolver().openInputStream(uri);
                ZipInputStream zip=new ZipInputStream(new BufferedInputStream(input))){
                ZipEntry entry;
                while((entry=zip.getNextEntry())!=null){
                    if(++entries>18000)throw new IOException("ZIP内のファイルが多すぎます");
                    String name=entry.getName();
                    if(!safeZipEntry(name))throw new IOException("不正なZIPのファイル名です");
                    if(name.contains("/料理/"))containsCookingFolder=true;
                    if(!entry.isDirectory() && photoZipEntry(name))total++;
                    if(!entry.isDirectory() && name.toLowerCase(Locale.ROOT).endsWith(".json")){
                        try{String d=takeoutPhotoDate(zipBytes(zip,128*1024));if(!d.isEmpty())metadata.put(zipKey(name),d);}
                        catch(IOException ignored){}
                    }
                    zip.closeEntry();
                }
            }
            if(total==0){zipStatus("ZIPに写真が見つかりません。料理アルバムのZIPを選択してください");return;}
            final boolean albumFolder=containsCookingFolder;
            zipStatus("取り込み開始：写真"+total+"枚を確認しています");
            // Second pass streams one photo at a time without extracting the ZIP
            // archive to disk. The UI acknowledges every successful DB commit.
            try(InputStream input=getContentResolver().openInputStream(uri);
                ZipInputStream zip=new ZipInputStream(new BufferedInputStream(input))){
                ZipEntry entry;
                while((entry=zip.getNextEntry())!=null && !stopZipImport){
                    String name=entry.getName();
                    if(entry.isDirectory() || !photoZipEntry(name) || (albumFolder && !name.contains("/料理/"))){zip.closeEntry();continue;}
                    if(imported+skipped>=1500){zipStatus("一度に登録できる写真は1500枚までです");break;}
                    if(entry.getSize()>35*1024*1024L){skipped++;zip.closeEntry();continue;}
                    byte[] photo;
                    try {photo=zipBytes(zip,35*1024*1024);}
                    catch(Exception err){skipped++;zip.closeEntry();continue;}
                    zip.closeEntry();
                    String date=metadata.getOrDefault(name,"");
                    if(date.isEmpty())date=zipFileDate(photo);
                    if(date.isEmpty()){skipped++;continue;}
                    byte[] optimized=zipPhotoToJpeg(photo);photo=null;
                    if(optimized==null){skipped++;continue;}
                    String fingerprint=name+":"+entry.getCrc()+":"+entry.getSize();
                    String js="window.dinnerZipItem("+JSONObject.quote(name)+","+
                        JSONObject.quote(android.util.Base64.encodeToString(optimized,android.util.Base64.NO_WRAP))+","+
                        JSONObject.quote(date)+","+JSONObject.quote(fingerprint)+")";
                    zipAckResponse="";
                    CountDownLatch latch=new CountDownLatch(1);
                    zipAckLatch.set(latch);
                    runOnUiThread(()->{if(webView!=null&&!isFinishing())webView.evaluateJavascript(js,null);else latch.countDown();});
                    if(!latch.await(120,TimeUnit.SECONDS))throw new IOException("写真保存の応答がありません。取り込みを中断しました");
                    zipAckLatch.compareAndSet(latch,null);
                    if("ok".equals(zipAckResponse))imported++;
                    else if("skip".equals(zipAckResponse))skipped++;
                    else throw new IOException("写真の保存中にエラーが発生しました。容量を確認してください");
                    if((imported+skipped)%5==0)zipStatus("取り込み中："+imported+"枚保存、"+skipped+"枚スキップ");
                }
            }
            zipStatus((stopZipImport?"取り込みを中断しました。":"取り込み完了。")+"保存"+imported+"枚、スキップ"+skipped+"枚。撮影日がない写真は通常の選択から追加してください");
        }catch(Exception error){zipStatus("取り込み停止："+error.getMessage()+"（保存済みの記録は保持されています）");}
        finally{zipBusy=false;zipAckLatch.set(null);}
    }

    private void collectPhotoDate(Uri uri) {
        String name = null;
        long size = -1;
        String exifDate = null;
        String dateFromMedia = null;
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                int takenIndex = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN);
                if (nameIndex >= 0) name = cursor.getString(nameIndex);
                if (sizeIndex >= 0) size = cursor.getLong(sizeIndex);
                if (takenIndex >= 0 && !cursor.isNull(takenIndex)) {
                    long timestamp = cursor.getLong(takenIndex);
                    if (timestamp > 946684800000L)
                        dateFromMedia = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(timestamp));
                }
            }
        } catch (Exception ignored) { }
        try (InputStream stream = getContentResolver().openInputStream(uri)) {
            if (stream != null) {
                ExifInterface exif = new ExifInterface(stream);
                String raw = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL);
                if (raw == null) raw = exif.getAttribute(ExifInterface.TAG_DATETIME_DIGITIZED);
                if (raw == null) raw = exif.getAttribute(ExifInterface.TAG_DATETIME);
                if (raw != null && raw.matches("\\d{4}:\\d{2}:\\d{2}.*")) {
                    exifDate = raw.substring(0,10).replace(':','-');
                }
            }
        } catch (Exception ignored) { }
        String date = exifDate != null ? exifDate : dateFromMedia;
        if (date != null && name != null && size >= 0) capturedDates.put(name+"#"+size,date);
    }

    private void startDinnerScan() {
        String permission = Build.VERSION.SDK_INT >= 33 ?
                Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= 34) {
                requestPermissions(new String[] { Manifest.permission.READ_MEDIA_IMAGES,
                        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED }, SCAN_PHOTOS_REQUEST);
            } else {
                requestPermissions(new String[] { permission }, SCAN_PHOTOS_REQUEST);
            }
            return;
        }
        new Thread(this::scanDinnerPhotos, "DinnerGalleryScan").start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != SCAN_PHOTOS_REQUEST) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            startDinnerScan();
        } else {
            runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onDinnerNativeError('写真へのアクセスが限定されています。設定からすべての写真を許可してください')",null));
        }
    }

    private void scanDinnerPhotos() {
        JSONArray matches = new JSONArray();
        int scanned = 0;
        int timeMatched = 0;
        try (Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[] { MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN,
                        MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DISPLAY_NAME,
                        MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.MIME_TYPE }, null, null,
                MediaStore.Images.Media.DATE_TAKEN + " DESC")) {
            if (cursor != null) {
                while(cursor.moveToNext() && matches.length() < 12000) {
                    scanned++;
                    String filename = cursor.getString(3);
                    String folder = cursor.getString(4);
                    String mime = cursor.getString(5);
                    String description = ((filename == null ? "" : filename) + " " +
                            (folder == null ? "" : folder)).toLowerCase(Locale.ROOT);
                    if (description.contains("screenshot") || description.contains("screen_shot") ||
                            description.contains("screen shot") || description.contains("screencap") ||
                            description.contains("screenrecord") || description.contains("screen_record") ||
                            description.contains("スクリーンショット") || description.contains("screenshots/") ||
                            description.contains("screen captures/") || description.contains("screen_capture") ||
                            description.contains("/downloads/") || description.contains("download/")) continue;
                    if (mime == null || !mime.startsWith("image/")) continue;
                    long ts = cursor.getLong(1);
                    if (ts <= 0) ts = cursor.getLong(2) * 1000L;
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTimeInMillis(ts);
                    int hour = calendar.get(Calendar.HOUR_OF_DAY);
                    if (hour < 0 || hour >= 24) continue; // Filter by user-selected time in app.js
                    timeMatched++;
                    JSONObject photo = new JSONObject();
                    photo.put("id", cursor.getLong(0));
                    photo.put("ts", ts);
                    matches.put(photo);
                }
            }
            JSONObject report = new JSONObject();
            report.put("items",matches);
            report.put("scanned",scanned);
            report.put("timeMatched",timeMatched);
            final String javascript = "window.onDinnerNativeScan("+report.toString()+")";
            runOnUiThread(() -> webView.evaluateJavascript(javascript,null));
        } catch (Exception ex) {
            runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onDinnerNativeError('写真フォルダの読み取りに失敗しました')",null));
        }
    }

    private void openUpdatePage() {
        if (pendingDownloadId != -1L) {
            showUpdateStatus("ダウンロード状態を確認しています…");
            pollUpdateDownload();
            return;
        }
        try {
            // Cache buster ensures GitHub's stable download path resolves the latest APK.
            Uri url = Uri.parse("https://raw.githubusercontent.com/osakakon-ai/fx-souba-yosou-update/main/dinner/Dinner-Photo-Log.apk?v=" + System.currentTimeMillis());
            File oldApk = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Dinner-Photo-Log-update.apk");
            if (oldApk.isFile() && !oldApk.delete()) {
                showUpdateStatus("保存済みの更新ファイルを削除できません。端末容量を確認してください");
                return;
            }
            DownloadManager.Request request = new DownloadManager.Request(url);
            request.setTitle("晩ごはん記録 更新");
            request.setDescription("最新版をダウンロードしています");
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "Dinner-Photo-Log-update.apk");
            DownloadManager manager = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
            pendingDownloadId = manager.enqueue(request);
            getPreferences(MODE_PRIVATE).edit().putLong("pending_apk_download", pendingDownloadId).apply();
            showUpdateStatus("ダウンロードを開始しました");
            scheduleUpdateCheck();
        } catch (Exception err) {
            pendingDownloadId = -1L;
            showUpdateStatus("更新を開始できませんでした: " + err.getClass().getSimpleName());
        }
    }

    private void installDownloadedUpdate() {
        try {
            File file = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Dinner-Photo-Log-update.apk");
            if (!file.isFile() || file.length() < 10000) {
                showMessage("更新ファイルが見つかりません");
                return;
            }
            android.content.pm.PackageInfo archived = getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(), 0);
            if (archived == null || !getPackageName().equals(archived.packageName)) {
                showMessage("更新ファイルが正しくありません");
                return;
            }
            long available = Build.VERSION.SDK_INT >= 28 ? archived.getLongVersionCode() : archived.versionCode;
            long installed = 0;
            try {
                android.content.pm.PackageInfo current = getPackageManager().getPackageInfo(getPackageName(), 0);
                installed = Build.VERSION.SDK_INT >= 28 ? current.getLongVersionCode() : current.versionCode;
            } catch (Exception ignored) { }
            if (available <= installed) {
                showUpdateStatus("すでに最新版です（v" + archived.versionName + "）。インストールは不要です");
                installerPending = false;
                return;
            }
            showMessage("新版 v" + archived.versionName + " のインストール確認へ進みます");
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                showUpdateStatus("インストール許可が必要です。許可後にインストール画面へ進みます");
                installerPending = true;
                Intent settings = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                startActivity(settings);
                return;
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
            Intent install = new Intent(Intent.ACTION_VIEW);
            install.setDataAndType(uri, "application/vnd.android.package-archive");
            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            installerPending = false;
            showUpdateStatus("Androidのインストール確認画面を開きます");
            startActivity(install);
        } catch (Exception err) {
            installerPending = false;
            showUpdateStatus("インストール画面を開けませんでした: " + err.getClass().getSimpleName());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (pendingDownloadId != -1L) scheduleUpdateCheck();
        if (installerPending && (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls())) {
            // Run after returning from the system's unknown-sources permission screen.
            new android.os.Handler(getMainLooper()).post(this::installDownloadedUpdate);
        }
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void scanDinnerPhotos() { runOnUiThread(MainActivity.this::startDinnerScan); }
        @JavascriptInterface
        public String photoDateFor(String name, String size) {
            String result = capturedDates.get(name+"#"+size);
            return result == null ? "" : result;
        }
        @JavascriptInterface
        public void chooseSinglePhoto() {runOnUiThread(MainActivity.this::openSinglePhotoPicker);}
        @JavascriptInterface
        public void chooseGoogleAlbumZip() {runOnUiThread(MainActivity.this::openAlbumZipPicker);}
        @JavascriptInterface
        public void cancelGoogleAlbumZip() {stopZipImport=true;}
        @JavascriptInterface
        public void zipItemSaved(String response) {
            zipAckResponse=response;
            CountDownLatch latch=zipAckLatch.get();
            if(latch!=null)latch.countDown();
        }
        @JavascriptInterface
        public void refreshApp() {
            runOnUiThread(MainActivity.this::openUpdatePage);
        }
    }
    @Override
    protected void onDestroy() {
        updateHandler.removeCallbacks(updateCheck);
        try { unregisterReceiver(downloadReceiver); } catch (Exception ignored) { }
        if(webView != null) { webView.removeJavascriptInterface("AndroidApp"); webView.destroy(); }
        super.onDestroy();
    }
}
