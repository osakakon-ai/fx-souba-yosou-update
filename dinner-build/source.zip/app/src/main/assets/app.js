'use strict';
(() => {
  const VERSION = '0.3.3';
  const $ = id => document.getElementById(id);
  const state = {db: null, entries: [], staged: [], cursor: new Date(), selectedDay: null, editId: null, galleryLimit: 60, galleryFilter: '', tab: 'calendarView'};
  state.cursor = new Date(state.cursor.getFullYear(), state.cursor.getMonth(), 1);
  const thumbs = new Map();
  let toastTimer;
  function say(message) { const t = $('toast'); t.textContent = message; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 3500); }
  function escapeHTML(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function isoDate(d = new Date()) { const y=d.getFullYear(), m=String(d.getMonth()+1).padStart(2,'0'), day=String(d.getDate()).padStart(2,'0'); return `${y}-${m}-${day}`; }
  function validDate(s) { if (!/^\d{4}-\d\d-\d\d$/.test(s)) return false; const d=new Date(s+'T12:00:00'); return !isNaN(d) && isoDate(d)===s; }
  function labelDate(s) { if (!validDate(s)) return s; const [y,m,d] = s.split('-'); return `${Number(y)}年${Number(m)}月${Number(d)}日`; }
  const byDate = (a,b) => b.date.localeCompare(a.date) || (b.capturedAt || '').localeCompare(a.capturedAt || '') || b.createdAt - a.createdAt;
  function id() { return (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : `img_${Date.now()}_${Math.random().toString(16).slice(2)}`; }
  function request(req) { return new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error || new Error('database error')); }); }
  async function openDB() {
    if (!('indexedDB' in window)) throw new Error('この環境では端末保存が利用できません');
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('dinner-photo-log-v1', 1);
      req.onupgradeneeded = () => { const db = req.result; const store = db.createObjectStore('entries', {keyPath:'id'}); store.createIndex('date','date',{unique:false}); db.createObjectStore('images',{keyPath:'id'}); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('写真データベースを開けません'));
      req.onblocked = () => reject(new Error('ほかの画面がデータベースを使用しています'));
    });
  }
  async function readAll() { state.entries = await request(state.db.transaction('entries','readonly').objectStore('entries').getAll()); state.entries.sort(byDate); }
  function txWrite(stores, action) { return new Promise((resolve,reject) => { const tx=state.db.transaction(stores,'readwrite'); tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error || new Error('保存できません')); tx.onabort=()=>reject(tx.error || new Error('保存処理を取り消しました')); action(tx); }); }
  async function saveEntry(info,blob,thumb) { await txWrite(['entries','images'],tx=>{ tx.objectStore('entries').put(info); tx.objectStore('images').put({id:info.id,blob,thumb}); }); }
  async function editEntry(info) { await txWrite(['entries'], tx=>tx.objectStore('entries').put(info)); }
  async function deleteEntry(idToDelete) { await txWrite(['entries','images'],tx=>{ tx.objectStore('entries').delete(idToDelete); tx.objectStore('images').delete(idToDelete); }); if (thumbs.has(idToDelete)) { URL.revokeObjectURL(thumbs.get(idToDelete)); thumbs.delete(idToDelete); } }
  async function getImage(itemId) { return request(state.db.transaction('images','readonly').objectStore('images').get(itemId)); }
  async function bindThumbnail(img,itemId,full=false) {
    if (!img || !img.isConnected) return;
    try {
      let url = thumbs.get(itemId);
      if (!url || full) {
        const stored = await getImage(itemId); if (!stored) return;
        const blob = (full ? stored.blob : stored.thumb || stored.blob);
        if (!blob) return;
        url = URL.createObjectURL(blob);
        if (!full) {
          thumbs.set(itemId,url);
          while (thumbs.size > 150) { const oldest=thumbs.keys().next().value; URL.revokeObjectURL(thumbs.get(oldest)); thumbs.delete(oldest); }
        }
      }
      if (img.isConnected && img.dataset.photoId === itemId) img.src=url;
      else if (full) URL.revokeObjectURL(url);
    } catch (e) { console.warn('写真読み込み失敗',e); }
  }
  function reRender() { state.entries.sort(byDate); renderCalendar(); renderFilters(); renderGallery(); }
  function tabTo(view) {
    state.tab = view;
    document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===view));
    document.querySelectorAll('.nav-btn').forEach(b=>{ const active = b.dataset.view===view; b.classList.toggle('active',active); b.setAttribute('aria-current', active?'page':'false'); });
    if (view==='galleryView') renderGallery();
    window.scrollTo(0,0);
  }
  document.querySelectorAll('.nav-btn').forEach(b=>b.addEventListener('click',()=>{ if(b.dataset.view==='addView')state.selectedDay=null; tabTo(b.dataset.view); }));
  function renderCalendar() {
    const y=state.cursor.getFullYear(), m=state.cursor.getMonth();
    $('monthTitle').textContent=`${y}年 ${m+1}月`;
    const first=new Date(y,m,1).getDay(), n=new Date(y,m+1,0).getDate(), today=isoDate();
    const counts=new Map(), firstPhoto=new Map();
    for (const entry of state.entries) { if (entry.date.startsWith(`${y}-${String(m+1).padStart(2,'0')}`)) { counts.set(entry.date, (counts.get(entry.date)||0)+1); if(!firstPhoto.has(entry.date)) firstPhoto.set(entry.date,entry.id); } }
    $('monthDays').innerHTML=`${counts.size}<span>日</span>`;
    $('monthPhotos').innerHTML=`${[...counts.values()].reduce((a,b)=>a+b,0)}<span>枚</span>`;
    let html='';
    for (let i=0;i<first;i++) html+='<div class="calendar-day empty" aria-hidden="true"></div>';
    for (let day=1;day<=n;day++) {
      const key=isoDate(new Date(y,m,day)), num=counts.get(key)||0, dow=(first+day-1)%7;
      html+=`<button type="button" class="calendar-day${num?' has-log':''}${key===today?' today':''}${dow===0?' sunday':dow===6?' saturday':''}" data-date="${key}" aria-label="${labelDate(key)}、写真${num}枚"><span class="day-number">${day}</span>${num ? `<img class="day-thumb" alt="" data-photo-id="${firstPhoto.get(key)}"><span class="day-count">${num}枚</span>` : '<span class="day-empty-label">·</span>'}</button>`;
    }
    $('calendarGrid').innerHTML=html;
    $('calendarGrid').querySelectorAll('[data-date]').forEach(b=>b.addEventListener('click',()=>openDay(b.dataset.date)));
    $('calendarGrid').querySelectorAll('img[data-photo-id]').forEach(img=>bindThumbnail(img,img.dataset.photoId));
  }
  $('prevMonthBtn').onclick=()=>{ state.cursor=new Date(state.cursor.getFullYear(),state.cursor.getMonth()-1,1); renderCalendar(); };
  $('nextMonthBtn').onclick=()=>{ state.cursor=new Date(state.cursor.getFullYear(),state.cursor.getMonth()+1,1); renderCalendar(); };
  $('todayBtn').onclick=()=>{ state.cursor=new Date(); state.cursor.setDate(1); renderCalendar(); };
  $('quickAddBtn').onclick=()=>{ state.selectedDay=null; tabTo('addView'); };
  function renderFilters() {
    const months=[...new Set(state.entries.map(e=>e.date.slice(0,7)))].sort().reverse();
    const current=$('filterMonth').value;
    $('filterMonth').innerHTML='<option value="">すべての月</option>'+months.map(m=>`<option value="${m}">${m.replace('-', '年')}月</option>`).join('');
    $('filterMonth').value=months.includes(current)?current:'';
  }
  function renderGallery() {
    if (!state.db) return;
    $('totalCount').textContent=`${state.entries.length}枚`;
    const query=$('searchInput').value.trim().toLocaleLowerCase('ja'); const month=$('filterMonth').value;
    const list=state.entries.filter(e=>(!month||e.date.startsWith(month)) && (!query || (`${e.title} ${e.note}`).toLocaleLowerCase('ja').includes(query)));
    const visible=list.slice(0,state.galleryLimit);
    $('galleryGrid').innerHTML=visible.length ? visible.map(e=>`<article class="photo-card"><button class="photo-card-image-button" type="button" data-viewphoto="${e.id}"><img class="photo-card-image" data-photo-id="${e.id}" alt="${escapeHTML(e.title||'晩ごはんの写真')}"></button><div class="photo-meta"><div class="photo-date">${labelDate(e.date)}</div><div class="photo-title">${escapeHTML(e.title||'晩ごはん')}</div>${e.note ? `<div class="photo-note">${escapeHTML(e.note)}</div>`:''}<div class="row-actions"><button class="small-btn" type="button" data-edit="${e.id}">編集</button><button class="small-btn" type="button" data-open-day="${e.date}">日付を見る</button></div></div></article>`).join('') : `<div class="empty-state">${state.entries.length ? '条件に合う記録がありません' : 'まだ晩ごはんの記録がありません。下の「写真を追加」から登録しましょう。'}</div>`;
    $('galleryGrid').querySelectorAll('img[data-photo-id]').forEach(img=>bindThumbnail(img,img.dataset.photoId));
    $('loadMoreBtn').classList.toggle('hidden',visible.length>=list.length);
    $('galleryGrid').querySelectorAll('[data-viewphoto]').forEach(b=>b.onclick=()=>showPhoto(b.dataset.viewphoto));
    $('galleryGrid').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>openEdit(b.dataset.edit));
    $('galleryGrid').querySelectorAll('[data-open-day]').forEach(b=>b.onclick=()=>openDay(b.dataset.openDay));
  }
  $('filterMonth').onchange=()=>{state.galleryLimit=60;renderGallery();};
  $('searchInput').oninput=()=>{state.galleryLimit=60;renderGallery();};
  $('loadMoreBtn').onclick=()=>{state.galleryLimit+=60;renderGallery();};
  // Full-width day viewer: display the saved main image, not the cropped calendar thumbnail.
  const dayImageUrls = new Map();
  function releaseDayImages() {
    for (const url of dayImageUrls.values()) URL.revokeObjectURL(url);
    dayImageUrls.clear();
  }
  async function attachDayImage(img, itemId) {
    try {
      const row = await getImage(itemId);
      if (!(row?.blob || row?.thumb) || !img.isConnected || !$('dayDialog').open || img.dataset.photoId !== itemId) return;
      const url = URL.createObjectURL(row.blob || row.thumb);
      if (!img.isConnected || !$('dayDialog').open || img.dataset.photoId !== itemId) {
        URL.revokeObjectURL(url);
        return;
      }
      dayImageUrls.set(itemId, url);
      img.src = url;
    } catch (error) {
      console.warn('日付の写真を読み込めませんでした', error);
    }
  }
  async function openDay(date) {
    state.selectedDay=date;
    releaseDayImages();
    const dayEntries=state.entries.filter(e=>e.date===date);
    $('dayTitle').textContent=`${labelDate(date)} の晩ごはん`;
    $('dayContent').innerHTML=dayEntries.length ? dayEntries.map(e=>`<article class="day-photo"><img style="display:block;width:100%;height:auto;max-width:100%;object-fit:contain;" class="day-full-image" alt="${escapeHTML(e.title || '料理の写真')}" data-photo-id="${e.id}"><div class="details"><div class="day-photo-caption"><strong>${escapeHTML(e.title||'晩ごはん')}</strong><small>${e.capturedAt ? `撮影 ${escapeHTML(e.capturedAt.slice(11,16))}` : '写真記録'}</small></div>${e.note?`<p>${escapeHTML(e.note)}</p>`:''}<div class="row-actions"><button type="button" class="small-btn" data-day-edit="${e.id}">編集</button><button type="button" class="small-btn" data-day-delete="${e.id}">削除</button></div></div></article>`).join('') : '<div class="empty-state">この日の写真はまだありません</div>';
    $('dayDialog').showModal();
    $('dayDialog').scrollTop=0;
    $('dayContent').querySelectorAll('img.day-full-image').forEach(img=>attachDayImage(img,img.dataset.photoId));
    $('dayContent').querySelectorAll('[data-day-edit]').forEach(b=>b.onclick=()=>{ $('dayDialog').close(); openEdit(b.dataset.dayEdit); });
    $('dayContent').querySelectorAll('[data-day-delete]').forEach(b=>b.onclick=()=>confirmDelete(b.dataset.dayDelete,date));
  }
  $('dayDialog').addEventListener('close',releaseDayImages);
  $('closeDayBtn').onclick=()=>$('dayDialog').close();
  $('addForDayBtn').onclick=()=>{ $('dayDialog').close(); tabTo('addView'); say('写真に撮影日がある場合は撮影日を優先します。保存前に日付を確認できます。'); };
  async function showPhoto(itemId) {
    const e=state.entries.find(x=>x.id===itemId); if (!e) return;
    const img=$('photoFull'); if (img.dataset.url) { URL.revokeObjectURL(img.dataset.url); delete img.dataset.url; }
    img.removeAttribute('src'); $('photoCaption').textContent=`${labelDate(e.date)}　${e.title||'晩ごはん'}${e.note?'\n'+e.note:''}`;
    $('photoDialog').showModal();
    try {const row=await getImage(itemId); if(row?.blob && $('photoDialog').open){const url=URL.createObjectURL(row.blob);img.dataset.url=url;img.src=url;}} catch { say('画像を読み込めませんでした'); }
  }
  $('closePhotoBtn').onclick=()=>$('photoDialog').close();
  $('photoDialog').addEventListener('close',()=>{const img=$('photoFull');if(img.dataset.url){URL.revokeObjectURL(img.dataset.url);delete img.dataset.url;}img.removeAttribute('src');});
  async function openEdit(itemId) {
    const entry=state.entries.find(e=>e.id===itemId); if (!entry) return;
    state.editId=itemId; $('editDate').value=entry.date; $('editTitle').value=entry.title||''; $('editNote').value=entry.note||'';
    $('editPreview').innerHTML=`<img alt="編集する写真" data-photo-id="${itemId}">`;
    $('editDialog').showModal(); bindThumbnail($('editPreview').querySelector('img'),itemId);
  }
  $('closeEditBtn').onclick=()=>$('editDialog').close();
  $('editForm').onsubmit=async ev=>{
    ev.preventDefault();const entry=state.entries.find(e=>e.id===state.editId);if(!entry)return;
    const date=$('editDate').value;if(!validDate(date)){say('正しい日付を指定してください');return;}
    const updated={...entry,date,title:$('editTitle').value.trim(),note:$('editNote').value.trim()};
    try {await editEntry(updated);Object.assign(entry,updated);$('editDialog').close();state.cursor=new Date(date+'T12:00:00');state.cursor.setDate(1);reRender();say('記録を変更しました');} catch(e){say(`編集エラー: ${e.message}`);}
  };
  async function confirmDelete(idToDelete,refreshDay) {
    if(!confirm('この写真の記録を削除しますか？ この操作は取り消せません。'))return;
    try {await deleteEntry(idToDelete);state.entries=state.entries.filter(e=>e.id!==idToDelete);reRender();if($('editDialog').open)$('editDialog').close();if(refreshDay && $('dayDialog').open){$('dayDialog').close();openDay(refreshDay);}say('記録を削除しました');}catch(e){say(`削除エラー: ${e.message}`);}
  }
  $('deleteEditBtn').onclick=()=>confirmDelete(state.editId);
  // JPEGのEXIF DateTimeOriginal(0x9003)を最優先で解析。取得不能ならAndroid側のMediaStore情報を使います。
  async function readExifDate(file) {
    if (!/jpe?g/i.test(file.type) && !/\.(jpe?g)$/i.test(file.name)) return null;
    try {
      const data = new DataView(await file.slice(0, Math.min(file.size, 512*1024)).arrayBuffer());
      if (data.byteLength<8 || data.getUint16(0)!==0xffd8) return null;
      let offset=2;
      function parseTiff(tiff,appEnd) {
        if(tiff+8>appEnd)return null;
        const mark=data.getUint16(tiff);const little=mark===0x4949;if(!little && mark!==0x4d4d)return null;
        const u16=o=>o>=tiff&&o+2<=appEnd?data.getUint16(o,little):null;
        const u32=o=>o>=tiff&&o+4<=appEnd?data.getUint32(o,little):null;
        if(u16(tiff+2)!==42)return null;
        const readDateAt=(pointer,count)=>{
          if(pointer===null||count<19 || count>1000) return null;
          const pos=tiff+pointer; if(pos<tiff||pos+19>appEnd)return null;
          let str='';for(let i=0;i<19;i++)str+=String.fromCharCode(data.getUint8(pos+i));
          const match=/^(\d{4}):(\d\d):(\d\d) (\d\d):(\d\d):(\d\d)/.exec(str);
          if(!match)return null;
          const date=`${match[1]}-${match[2]}-${match[3]}`;return validDate(date)?{date, capturedAt:`${date}T${match[4]}:${match[5]}:${match[6]}`,source:'EXIF撮影日'}:null;
        };
        function parseIFD(ptr){
          if(ptr===null||ptr>appEnd-tiff-2)return {date:null,next:null};
          const start=tiff+ptr, num=u16(start);if(num==null||num>2000||start+2+num*12>appEnd)return {date:null,next:null};
          let date=null,next=null;
          for(let i=0;i<num;i++){
            const a=start+2+i*12,tag=u16(a),type=u16(a+2),count=u32(a+4),value=u32(a+8);
            if(tag===0x8769)next=value;
            if((tag===0x9003 || tag===0x9004 || tag===0x0132) && type===2)date=readDateAt(value,count)||date;
            if(tag===0x9003 && date)return {date,next};
          }
          return {date,next};
        }
        const base=parseIFD(u32(tiff+4));const ext=base.next!==null?parseIFD(base.next):{date:null};return ext.date||base.date;
      }
      while(offset+4<data.byteLength) {
        if(data.getUint8(offset)!==0xff)break;
        const marker=data.getUint8(offset+1);if(marker===0xd9 || marker===0xda)break;
        const length=data.getUint16(offset+2);if(length<2 || offset+2+length>data.byteLength)break;
        if(marker===0xe1 && length>=16 && data.getUint32(offset+4)===0x45786966 && data.getUint16(offset+8)===0) {
          const out=parseTiff(offset+10,offset+2+length);if(out)return out;
        }
        offset+=2+length;
      }
    } catch(e){ console.warn('EXIF読込失敗',e); }
    return null;
  }
  async function dateForFile(file) {
    const exif=await readExifDate(file);if(exif)return exif;
    try { if(window.AndroidApp?.photoDateFor){const native=window.AndroidApp.photoDateFor(file.name,String(file.size));if(validDate(native))return {date:native,capturedAt:'',source:'スマホの撮影日時'};} }catch(e){console.warn(e);}
    if(state.selectedDay)return {date:state.selectedDay,capturedAt:'',source:'選択したカレンダー日付（要確認）'};
    const filenameDate = /(?:^|[^0-9])((?:19|20)\d{2})[-_]?([01]\d)[-_]?([0-3]\d)(?:[^0-9]|$)/.exec(file.name);
    if(filenameDate) { const candidate=`${filenameDate[1]}-${filenameDate[2]}-${filenameDate[3]}`; if(validDate(candidate))return {date:candidate,capturedAt:'',source:'ファイル名から推定（要確認）'}; }
    if(file.lastModified>946684800000 && file.lastModified<Date.now()+86400000){const d=new Date(file.lastModified);return {date:isoDate(d),capturedAt:'',source:'ファイル更新日（要確認）'};}
    return {date:isoDate(),capturedAt:'',source:'今日の日付（要確認）'};
  }
  async function addToQueue(file) {
    if(!file.type.startsWith('image/') && !/\.(heic|heif|jpe?g|png|webp|gif|avif)$/i.test(file.name))return;
    const dateInfo=await dateForFile(file);
    state.staged.push({id:id(),file,date:dateInfo.date,capturedAt:dateInfo.capturedAt,source:dateInfo.source,title:'',note:'',preview:URL.createObjectURL(file)});
  }
  $('photoInput').addEventListener('change',async ev=>{
    const files=Array.from(ev.target.files||[]);if(!files.length)return;
    say(`${files.length}枚の撮影日時を確認しています`);
    for(const f of files)await addToQueue(f);
    ev.target.value='';renderQueue();say(`${files.length}枚を選びました。日付を確認してください`);
  });
  function renderQueue() {
    $('queueContainer').innerHTML=state.staged.map(item=>`<div class="queue-card card" data-queue-id="${item.id}"><img class="queue-thumb" alt="追加する写真" data-staged-preview="${item.id}"><div class="queue-body"><span class="queue-name" title="${escapeHTML(item.file.name)}">${escapeHTML(item.file.name)}</span><label class="field-label">記録する日付<input data-prop="date" type="date" value="${escapeHTML(item.date)}" required></label><span class="source-tag">${escapeHTML(item.source)}</span><label class="field-label">料理名<input data-prop="title" maxlength="80" placeholder="未入力でもOK" value="${escapeHTML(item.title)}"></label><label class="field-label">メモ<input data-prop="note" maxlength="600" placeholder="ひとこと" value="${escapeHTML(item.note)}"></label><button data-remove="${item.id}" class="small-btn" type="button">この写真を外す</button></div></div>`).join('');
    $('queueContainer').querySelectorAll('[data-staged-preview]').forEach(img=>img.src=state.staged.find(x=>x.id===img.dataset.stagedPreview).preview);
    $('queueContainer').querySelectorAll('[data-queue-id]').forEach(div=>{const item=state.staged.find(x=>x.id===div.dataset.queueId);div.querySelectorAll('[data-prop]').forEach(field=>field.addEventListener('input',()=>{item[field.dataset.prop]=field.value;}));});
    $('queueContainer').querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{const i=state.staged.findIndex(s=>s.id===b.dataset.remove);if(i>=0){URL.revokeObjectURL(state.staged[i].preview);state.staged.splice(i,1);renderQueue();}});
    $('queueCount').textContent=`(${state.staged.length}枚)`;$('queueActions').classList.toggle('hidden',!state.staged.length);
  }
  $('clearQueueBtn').onclick=()=>{state.staged.forEach(s=>URL.revokeObjectURL(s.preview));state.staged=[];renderQueue();};
  function canvasToBlob(canvas,mime,quality){return new Promise(resolve=>canvas.toBlob(resolve,mime,quality));}
  // Decode the original once, create both saved photo and thumbnail from the same bitmap.
  // Previous versions decoded every large photo twice, increasing import time and memory usage.
  async function optimizedPair(file){
    if(!file.type.startsWith('image/')||file.type==='image/gif'||file.type==='image/svg+xml')return {body:file,thumb:file};
    let bitmap;
    try{
      if('createImageBitmap' in window)bitmap=await createImageBitmap(file,{imageOrientation:'from-image'});
      else bitmap=await new Promise((resolve,reject)=>{
        const u=URL.createObjectURL(file),im=new Image();
        im.onload=()=>{URL.revokeObjectURL(u);resolve(im)};
        im.onerror=()=>{URL.revokeObjectURL(u);reject(new Error('decode'))};im.src=u;
      });
      const make=async(maxWidth,quality)=>{
        const ratio=Math.min(1,maxWidth/Math.max(bitmap.width,bitmap.height));
        const w=Math.max(1,Math.round(bitmap.width*ratio));
        const h=Math.max(1,Math.round(bitmap.height*ratio));
        const c=document.createElement('canvas');c.width=w;c.height=h;
        const ctx=c.getContext('2d',{alpha:false});
        ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);ctx.drawImage(bitmap,0,0,w,h);
        const blob=await canvasToBlob(c,'image/jpeg',quality);
        c.width=c.height=1;
        return blob||file;
      };
      const body=await make(1600,.79),thumb=await make(360,.7);
      return {body,thumb};
    }catch(e){console.warn('画像をそのまま保存',e);return {body:file,thumb:file};}
    finally{if(bitmap?.close)bitmap.close();}
  }
  $('saveQueueBtn').onclick=async()=>{
    if(!state.db){say('保存先を初期化できていません');return;}
    if(!state.staged.length)return;
    if(state.staged.some(s=>!validDate(s.date))){say('正しくない日付があります。日付を確認してください');return;}
    const btn=$('saveQueueBtn');btn.disabled=true;let saved=0;let mostRecentlySavedDate=null;
    try {
      for(const s of [...state.staged]){
        btn.textContent=`保存中… ${saved+1}/${state.staged.length}`;
        const {body:blob,thumb}=await optimizedPair(s.file);
        const entry={id:s.id,date:s.date,capturedAt:s.capturedAt,source:s.source,title:s.title.trim(),note:s.note.trim(),filename:s.file.name,createdAt:Date.now()};
        await saveEntry(entry,blob,thumb);state.entries.push(entry);saved++;mostRecentlySavedDate=entry.date;
        URL.revokeObjectURL(s.preview);
        state.staged=state.staged.filter(x=>x.id!==s.id);
      }
      state.selectedDay=null;renderQueue();reRender();
      if(mostRecentlySavedDate){state.cursor=new Date(mostRecentlySavedDate+'T12:00:00');state.cursor.setDate(1);renderCalendar();}
      tabTo('calendarView');say(`${saved}枚の晩ごはんを登録しました`);
    }catch(e){console.error(e);say(`${saved}枚を保存。残りは未保存です: ${e.name==='QuotaExceededError'?'端末の容量が足りません':e.message}`);renderQueue();reRender();}
    finally{btn.disabled=false;btn.innerHTML='写真を保存 <span id="queueCount"></span>';const c=$('queueCount');if(c)c.textContent=`(${state.staged.length}枚)`;}
  };

  // MediaStore scan returns metadata only. Thumbnails are decoded at low resolution.
  // Brown/orange tray detection is a fallible local color heuristic, not an AI food classifier.
  let autoCandidates=[],autoVisible=0,scanRunning=false,colorJob=0,colorBusy=false,showPossible=false;
  let scannedLibrary=[], scannedLibraryCount=0, scannedLibraryTruncated=false;
  const scanTimeMode=$('scanTimeMode'), scanFilterMode=$('scanFilterMode'), scanHours=$('scanCustomHours');
  const scanStartHour=$('scanStartHour'), scanEndHour=$('scanEndHour');
  [scanStartHour,scanEndHour].forEach((el,index)=>{for(let h=0;h<24;h++){const o=document.createElement('option');o.value=String(h);o.textContent=String(h).padStart(2,'0')+'時';el.append(o);}el.value=index?'21':'18';});
  const inSelectedTime=ts=>{
    const dt=new Date(Number(ts));if(!Number.isFinite(+dt))return false;
    const h=dt.getHours();
    if(scanTimeMode.value==='all')return true;
    if(scanTimeMode.value==='lunch')return h>=11&&h<15;
    if(scanTimeMode.value==='custom'){
      const a=Number(scanStartHour.value),b=Number(scanEndHour.value);
      return a<b?(h>=a&&h<b):(h>=a||h<b);
    }
    return h>=18&&h<21;
  };
  function timeModeLabel(){
    if(scanTimeMode.value==='all')return '全時間';
    if(scanTimeMode.value==='lunch')return '昼11〜15時';
    if(scanTimeMode.value==='custom')return `指定${scanStartHour.value}〜${scanEndHour.value}時`;
    return '夕18〜21時';
  }
  function selectedModeLabel(){return scanFilterMode.value==='all'?'時刻で一覧':scanFilterMode.value==='broad'?'料理を広く探す':'料理を優先';}


  const nativeBase='https://appassets.androidplatform.net/photo/';
  const nativeThumbBase='https://appassets.androidplatform.net/thumb/';
  const autoDisplayDate=ts=>{
    const d=new Date(ts);if(!Number.isFinite(+d))return '撮影日不明';
    return `${d.getFullYear()}/${d.getMonth()+1}/${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  };
  function trayColorScore(bitmap){
    // More forgiving, on-device recognition for orange/brown tray + white dishes.
    // Keep the original food photos: portrait orientation is not a screenshot signal.
    const W=96,H=64;
    const cv=document.createElement('canvas');cv.width=W;cv.height=H;
    const ctx=cv.getContext('2d',{willReadFrequently:true});ctx.drawImage(bitmap,0,0,W,H);
    const pixels=ctx.getImageData(0,0,W,H).data;
    let tray=0,white=0,trayAtEdge=0,edgeTotal=0,detail=0,detailTotal=0;
    let centerWhite=0,centerCount=0;
    const trayQuads=[0,0,0,0],whiteCells=new Array(16).fill(0);
    for(let y=0;y<H;y++)for(let x=0;x<W;x++){
      const i=(y*W+x)*4,r=pixels[i],g=pixels[i+1],b=pixels[i+2];
      const hi=Math.max(r,g,b),lo=Math.min(r,g,b);
      // Smartphone cameras vary in lightness, exposure and white balance.
      const isTray=r>=62&&r>g*1.12&&g>b*1.07&&(r-b)>34&&(g-b)>9;
      const isDish=r>=123&&g>=119&&b>=109&&(hi-lo)<=58&&lo>=100;
      if(isTray){tray++;trayQuads[(x>=W/2?1:0)+(y>=H/2?2:0)]++;}
      if(isDish){white++;whiteCells[Math.floor(y*4/H)*4+Math.floor(x*4/W)]++;}
      if(x<W*.18||x>=W*.82||y<H*.14||y>=H*.86){edgeTotal++;if(isTray)trayAtEdge++;}
      if(x>=W*.20&&x<W*.80&&y>=H*.18&&y<H*.82){
        detailTotal++;
        if(r<152&&g<145&&b<130)detail++;
        centerCount++;if(isDish)centerWhite++;
      }
    }
    cv.width=cv.height=1;
    const total=W*H;
    const t=tray/total,w=white/total,e=trayAtEdge/Math.max(1,edgeTotal);
    const spreads=trayQuads.filter(n=>n/(total/4)>.045).length;
    const whiteSpread=whiteCells.filter(n=>n/(total/16)>.045).length;
    const d=detail/Math.max(1,detailTotal),middleWhite=centerWhite/Math.max(1,centerCount);
    // The earlier mandatory tray coverage >=20%, 3 quadrants, and pale-white
    // >=7.5% rejected virtually every dinner photo, especially in dim light.
    // Two routes support wide tray photos and close-ups of plates respectively.
    const trayScene=t>=.075&&e>=.085&&spreads>=1&&w>=.052&&w<=.83&&whiteSpread>=2&&d>=.023;
    const closeDish=t>=.037&&e>=.060&&w>=.145&&w<=.84&&whiteSpread>=2&&middleWhite>=.105&&d>=.032;
    const matching=trayScene||closeDish;
    const possible=!matching&&t>=.028&&e>=.040&&w>=.033&&whiteSpread>=1&&d>=.018;
    const confidence=Math.round(Math.min(100,100*(Math.min(1,e/.50)*.25+Math.min(1,t/.42)*.23+Math.min(1,w/.35)*.31+Math.min(1,d/.27)*.21)));
    return {matching,possible,confidence};
  }
  async function classifyTray(item){
    const url=nativeThumbBase+encodeURIComponent(item.id);
    const response=await fetch(url);
    if(!response.ok)throw new Error('thumbnail unavailable');
    const blob=await response.blob();
    if(!blob.size)throw new Error('empty thumbnail');
    let bm;
    try{
      if('createImageBitmap' in window)bm=await createImageBitmap(blob);
      else bm=await new Promise((resolve,reject)=>{
        const u=URL.createObjectURL(blob),im=new Image();im.onload=()=>{URL.revokeObjectURL(u);resolve(im)};im.onerror=()=>{URL.revokeObjectURL(u);reject(Error('image decode failed'))};im.src=u;
      });
      // Do not reject portrait shots. Most screenshots are filtered using the
      // MediaStore file name/folder before image decoding, even on edge 60 pro.
      return trayColorScore(bm);
    }finally{if(bm?.close)bm.close();}
  }
  const delayPaint=()=>new Promise(resolve=>setTimeout(resolve,0));
  function currentVisibleCandidates(){
    const mode=scanFilterMode.value;
    const list=autoCandidates.filter(x=>mode==='all'||x.tray==='match'||((mode==='broad'||showPossible)&&x.tray==='possible'));
    return list.sort((a,b)=>mode==='all'?b.ts-a.ts:((b.tray==='match')-(a.tray==='match'))||b.score-a.score||b.ts-a.ts);
  }
  function scanSummary(){
    const matched=autoCandidates.filter(x=>x.tray==='match').length;
    const total=autoCandidates.length;
    const possible=autoCandidates.filter(x=>x.tray==='possible').length;
    const failed=autoCandidates.filter(x=>x.tray==='unknown').length;
    const prefix=`端末内 ${scannedLibraryCount}枚を参照 / ${timeModeLabel()}の未登録 ${total}枚。`;
    const limit=scannedLibraryTruncated?' 検索上限に達しています。':'';
    if(scanFilterMode.value==='all')return prefix+'写真判定なしで全件を一覧表示しています。'+limit;
    if(colorBusy)return prefix+`料理らしさを判定中… ${autoCandidates.filter(x=>x.tray!=='pending').length}/${total}枚。`;
    return prefix+`料理候補 ${matched}枚、要確認 ${possible}枚。${failed?'読み取れない画像 '+failed+'枚。':''}${limit}`;
  }
  function presentScanChoices(){
    ++colorJob;
    colorBusy=false;
    $('trayScanProgress').classList.add('hidden');
    const registered=new Set(state.entries.filter(e=>e.mediaId!=null).map(e=>String(e.mediaId)));
    const oldMap=new Map(autoCandidates.map(x=>[x.id,x]));
    const ids=new Map();
    scannedLibrary.forEach(record=>{
      const id=String(record.id),ts=Number(record.ts);
      if(!registered.has(id)&&inSelectedTime(ts)&&!ids.has(id)){
        const old=oldMap.get(id);
        ids.set(id,{id,ts,selected:old?.selected||false,tray:old?.tray&&old.tray!=='pending'?old.tray:'pending',score:old?.score||0});
      }
    });
    autoCandidates=[...ids.values()];autoVisible=0;showPossible=false;
    $('autoResult').classList.toggle('hidden',!autoCandidates.length);
    $('scanStatus').textContent=scanSummary();
    renderAutoCandidates();
    if(autoCandidates.length&&scanFilterMode.value!=='all')evaluateTrayCandidates();
  }
  scanTimeMode.onchange=()=>{
    scanHours.classList.toggle('hidden',scanTimeMode.value!=='custom');
    if(scannedLibrary.length)presentScanChoices();
  };
  scanFilterMode.onchange=()=>{if(scannedLibrary.length)presentScanChoices();};
  scanStartHour.onchange=()=>{if(scannedLibrary.length)presentScanChoices();};
  scanEndHour.onchange=()=>{if(scannedLibrary.length)presentScanChoices();};
  async function evaluateTrayCandidates(){
    const token=++colorJob;colorBusy=true;
    const candidateItems=autoCandidates.filter(x=>x.tray==='pending');
    $('trayScanProgress').classList.remove('hidden');
    let next=0,done=0;
    async function worker(){
      while(token===colorJob&&next<candidateItems.length){
        const item=candidateItems[next++];
        try{
          const sc=await classifyTray(item);
          if(token!==colorJob)return;
          item.tray=sc.matching?'match':sc.possible?'possible':'other';item.score=sc.confidence;
          // Registration is deliberately opt-in to avoid saving wrong photos.
          item.selected=false;
        }catch(e){if(token!==colorJob)return;item.tray='unknown';}
        done++;
        if(done%24===0||done===candidateItems.length){
          $('trayProgressFill').style.width=`${100*done/candidateItems.length}%`;
          $('scanStatus').textContent=scanSummary();await delayPaint();
        }
      }
    }
    await Promise.all(Array.from({length:Math.min(3,candidateItems.length)},()=>worker()));
    if(token!==colorJob)return;
    colorBusy=false;$('trayScanProgress').classList.add('hidden');
    $('scanStatus').textContent=scanSummary();renderAutoCandidates();
  }
  $('scanDinnerBtn').onclick=()=>{
    if(!state.db){say('記録の保存機能が利用できません');return;}
    if(!window.AndroidApp&&!/Android/i.test(navigator.userAgent)){
      $('scanStatus').textContent='スマホのインストール版アプリで利用してください';return;
    }
    if(scanRunning)return;
    ++colorJob;colorBusy=false;scanRunning=true;$('scanDinnerBtn').disabled=true;
    $('trayScanProgress').classList.add('hidden');
    $('scanStatus').textContent='端末内の写真を読み込んでいます。初回は写真へのアクセスを許可してください。';
    location.href='dinnerscan://start';
    setTimeout(()=>{if(scanRunning){scanRunning=false;$('scanDinnerBtn').disabled=false;$('scanStatus').textContent='検索が完了しませんでした。写真のアクセス権限を確認してください。';}},60000);
  };
  window.onDinnerNativeError=message=>{
    scanRunning=false;$('scanDinnerBtn').disabled=false;$('scanStatus').textContent=message;
  };
  window.onDinnerNativeScan=report=>{
    ++colorJob;colorBusy=false;scanRunning=false;$('scanDinnerBtn').disabled=false;
    const items=Array.isArray(report)?report:(report?.items||[]);
    scannedLibraryCount=Number.isFinite(Number(report?.scanned))?Number(report.scanned):items.length;
    scannedLibraryTruncated=items.length>=12000;
    scannedLibrary=items.filter(x=>Number.isFinite(Number(x.ts))&&Number(x.ts)>0);
    if(scannedLibraryCount===0){
      $('autoResult').classList.add('hidden');
      $('scanStatus').textContent='参照できる写真は0枚です。「設定→アプリ→晩ごはん記録→権限→写真と動画」で「すべての写真」を許可してください。';return;
    }
    presentScanChoices();
  };
  function renderAutoCandidates(){
    const candidates=currentVisibleCandidates();
    const alternatives=autoCandidates.filter(x=>x.tray==='possible').length;
    const showExtra=scanFilterMode.value==='strict'&&!colorBusy&&alternatives>0;
    $('showAllAutoBtn').classList.toggle('hidden',!showExtra);
    $('showAllAutoBtn').hidden=!showExtra;
    $('showAllAutoBtn').textContent=showPossible?'要確認の写真を隠す':`見落とし候補も見る（${alternatives}枚）`;
    if(autoVisible===0)autoVisible=Math.min(candidates.length,60);
    const visible=candidates.slice(0,autoVisible);
    const noClassification=scanFilterMode.value==='all';
    $('autoCandidates').innerHTML=visible.map(x=>`<label class="auto-photo"><input type="checkbox" data-native-id="${x.id}" ${x.selected?'checked':''}><img loading="lazy" alt="写真候補" src="${nativeThumbBase}${encodeURIComponent(x.id)}"><span class="auto-photo-date">${autoDisplayDate(x.ts)}</span><span class="tray-label ${x.tray==='match'?'':'other'}">${noClassification?'撮影日時で検索':x.tray==='match'?'料理候補':'要確認'}</span></label>`).join('');
    $('autoCandidates').querySelectorAll('[data-native-id]').forEach(node=>node.onchange=()=>{
      const x=autoCandidates.find(e=>e.id===node.dataset.nativeId);if(x)x.selected=node.checked;updateAutoSelected();
    });
    $('autoMoreBtn').classList.toggle('hidden',autoVisible>=candidates.length);
    updateAutoSelected();
  }
  function updateAutoSelected(){
    const selected=autoCandidates.filter(x=>x.selected).length;
    $('autoResultCount').textContent=`表示 ${currentVisibleCandidates().length}枚 / 登録選択 ${selected}枚`;
    $('autoImportBtn').disabled=selected===0||colorBusy;
    const visible=currentVisibleCandidates().slice(0,autoVisible);
    $('autoToggleBtn').textContent=visible.length&&visible.every(x=>x.selected)?'表示中の写真をすべて外す':'表示中の写真をすべて選択';
  }
  $('showAllAutoBtn').onclick=()=>{showPossible=!showPossible;autoVisible=0;renderAutoCandidates();};
  $('autoMoreBtn').onclick=()=>{autoVisible=Math.min(autoVisible+60,currentVisibleCandidates().length);renderAutoCandidates();};
  $('autoToggleBtn').onclick=()=>{
    const visible=currentVisibleCandidates().slice(0,autoVisible);const checked=!visible.every(x=>x.selected);
    visible.forEach(x=>x.selected=checked);renderAutoCandidates();
  };
  $('autoImportBtn').onclick=async()=>{
    if(!state.db||colorBusy)return;
    const allowed=new Set(currentVisibleCandidates().map(x=>x.id));
    const selection=autoCandidates.filter(x=>x.selected&&allowed.has(x.id));
    if(!selection.length)return;
    const btn=$('autoImportBtn');btn.disabled=true;$('scanDinnerBtn').disabled=true;
    let saved=0,failed=0;const started=performance.now();
    for(const item of selection){
      btn.textContent=`登録中 ${saved+failed+1}/${selection.length}`;
      try{
        const response=await fetch(nativeBase+encodeURIComponent(item.id));
        if(!response.ok)throw Error('写真を読み込めません');
        const raw=await response.blob();if(!raw.size)throw Error('画像が空です');
        const file=new File([raw],`晩ごはん_${item.id}.jpg`,{type:raw.type||'image/jpeg',lastModified:item.ts});
        const date=isoDate(new Date(item.ts));
        const info={id:id(),date,capturedAt:new Date(item.ts).toISOString(),source:'写真フォルダ・'+timeModeLabel()+'・'+selectedModeLabel(),title:'',note:'',filename:file.name,mediaId:item.id,createdAt:Date.now()};
        const {body,thumb}=await optimizedPair(file);
        await saveEntry(info,body,thumb);state.entries.push(info);saved++;item.imported=true;
        // Allow the interface to paint between large batches.
        if(saved%3===0)await delayPaint();
      }catch(error){console.warn('自動登録失敗',item.id,error);failed++;item.selected=false;}
    }
    autoCandidates=autoCandidates.filter(x=>!x.imported);
    const imported=new Set(selection.filter(x=>x.imported).map(x=>x.id));
    scannedLibrary=scannedLibrary.filter(x=>!imported.has(String(x.id)));autoVisible=0;
    $('autoResult').classList.toggle('hidden',!autoCandidates.length);renderAutoCandidates();
    reRender();btn.disabled=false;$('scanDinnerBtn').disabled=false;
    btn.textContent='選択した写真をカレンダーへ登録';
    const seconds=((performance.now()-started)/1000).toFixed(1);
    $('scanStatus').textContent=`${saved}枚を登録しました（${seconds}秒）。${failed?'登録できなかった写真 '+failed+'枚は残しました。':''}`;
    if(saved){state.cursor=new Date();state.cursor.setDate(1);renderCalendar();say(`${saved}枚をカレンダーに登録しました`);}
  };

  let waitingForInstaller=false;
  window.dinnerUpdateStatus = message => {
    const label = document.getElementById('updateStatus');
    if (!label)return;
    if (String(message).includes('ダウンロード完了')) {
      waitingForInstaller=true;
      label.textContent='ダウンロード完了。更新バージョンを確認中…';
      // The native installer intentionally does not open for same/older APKs.
      setTimeout(()=>{
        if(waitingForInstaller && document.visibilityState==='visible') {
          label.textContent='インストール画面が開かない場合は、すでに最新版か更新ファイルを確認できていません。';
        }
      },2200);
    } else {
      waitingForInstaller=false; label.textContent=message;
    }
    label.hidden=false;
  };
  document.addEventListener('visibilitychange',()=>{
    if(waitingForInstaller && document.visibilityState==='hidden')waitingForInstaller=false;
  });
  $('updateBtn').onclick=()=>{
    // Android WebViewClient opens the stable APK download URL in the phone's browser.
    // A browser-only preview uses the same public download target.
    if (window.AndroidApp && typeof window.AndroidApp.refreshApp === 'function') {
      window.AndroidApp.refreshApp();
    } else {
      say('自動更新はAndroidアプリ版で利用できます');
    }
  };
  window.addEventListener('pagehide',()=>{for(const url of thumbs.values())URL.revokeObjectURL(url);});
  document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d)d.close();}));
  async function init() {
    try {state.db=await openDB();await readAll();renderCalendar();renderFilters();renderGallery();}
    catch(e){console.error(e);say('保存機能の起動に失敗しました。Androidアプリまたは対応ブラウザで開いてください');$('galleryGrid').innerHTML=`<div class="empty-state">保存機能を利用できません：${escapeHTML(e.message)}</div>`;}
  }
  init();
})();
