# 晩ごはん記録（Dinner Photo Log）v0.2.4

筋トレログのダークカレンダーを元に制作した、オフライン専用のAndroidアプリの初版ソースです。
筋トレアプリ本体とデータは完全に独立しており、アプリIDは `jp.osakakon.dinnerphotolog` です。

## 機能

- 日曜始まりカレンダー、日曜日は赤、土曜日は青、写真登録日はオレンジ丸、当日は緑枠
- スマホから過去の写真を複数選択し、撮影日ごとに登録
- JPEG EXIF DateTimeOriginal → AndroidのMediaStore / EXIF情報 → ファイル更新日（要確認） → 今日 の優先順で日付候補を設定
- 料理名・メモ、複数写真/日、日付移動、一覧検索、月フィルター、編集・削除
- IndexedDBを使って写真のコピー（最大1920px）とサムネイルをアプリ内部に保存、オフラインで表示
- 入力内容は端末内だけに保存。サーバー・クラウドへの写真アップロードなし

## 確認方法

`晩ごはん記録_お試し版.html` をスマホの対応ブラウザで開いて画面をお試しください。ブラウザのファイルURLには保存制限がある場合があり、本番利用にはAndroid APKが適しています。

## Android SDKを使った通常ビルド方法

Android SDK 35、JDK 17、Gradle 8.9以降を利用できる環境でこのフォルダを開き、`gradle assembleDebug` を実行すると `app/build/outputs/apk/debug/app-debug.apk` に出力されます。
`settings.gradle`, `build.gradle` と `app/` がプロジェクトルートです。
Android側は WebViewAssetLoader により HTTPS風のローカルオリジンで動かし、ブラウザストレージの安定性を高めています。

## 注意点

- 配布APKはSDK/Gradleではなく別途DEX組み立て・APK署名で作成済みです。Android SDKと実機での確認は未実施です。
- `更新` ボタンはGitHubで公開している最新APKの固定URLを外部ブラウザで開きます。Androidのダウンロード・インストール許可操作は利用者が行います。
- Androidの画像選択画面でユーザーが選んだ写真だけ読み込みます。18:00〜21:00の端末内写真検索はユーザーが検索ボタンを押したときに実行します。
- JPEG EXIFがない画像（スクリーンショットやSNSで再保存した画像、HEICの一部など）はAndroidの画像提供元が撮影日を返す場合のみ自動判別できます。日付候補は必ず確認してください。
- 端末のストレージ消去やアンインストールで記録も消去されます。オリジナル写真は端末の写真アプリで残し、次版でバックアップ/復元を実装することを推奨します。
- アプリに保存される写真は最適化されたコピーです。元の画質を保つための保存先ではありません。


## v0.2.0 夜間画像の自動抽出

- 写真アクセス権限の許可後にMediaStoreを検索し、撮影日時が18:00以上21:00未満の写真を候補表示します（最大500件）。
- 候補の画像はアプリ内の`/photo/{MediaStore ID}` で端末内から読み込み、カレンダーに登録すると最適化コピーをIndexedDBに保存します。
- 画像内容のAI分類は未実装です。料理以外が混ざるため登録前の選択・除外を可能にしています。
- 原本ファイルに変更を加えず、同じMediaStore IDの写真は重複登録を回避します。
- インストール可能APKは本ソースと同じ画面・処理を含みますが、SDK未導入のためAndroid実機の動作確認は未実施です。


## v0.2.2 / Android 14・15 の写真権限と検索結果表示
- Androidの部分選択アクセスと全件アクセスを区別。写真への権限が未付与の場合、全件アクセスを選べるシステムダイアログを表示します。
- MediaStoreで参照できた写真の枚数と18:00〜20:59の候補枚数を結果に表示。全件が0枚のときはアクセス権限の確認とGoogleフォトのクラウドのみの写真は検索対象外と表示します。
- 既存のAPKと同一パッケージ/同一署名で更新可能、写真の保存済み記録に削除処理なし。
- APK形式/署名/静的コード検証を実施。実機での動作確認は未実施です。


## v0.2.3 / 更新ボタン修正
- 以前は更新先未設定だった `更新` ボタンに、固定URL `https://github.com/osakakon-ai/fx-souba-yosou-update/raw/refs/heads/main/dinner/Dinner-Photo-Log.apk` を設定しました。
- Android WebViewの画面から `dinnerupdate://start` を開くと、ネイティブ側のWebViewClientがブラウザのダウンロード先を開きます。
- 最初の一回は前バージョンの更新ボタンが機能しないため、このv0.2.3 APKを手動で上書きインストールする必要があります。
- APKのパッケージID `jp.osakakon.dinnerphotolog` および既存署名は維持。versionCode 5 / versionName 0.2.3。
- GitHubにはこのビルドのAPK以外の個人写真は公開しません。
- アプリをアンインストールすると記録が消える可能性があります。必ず上書き更新してください。

## v0.2.4 / お盆の色で候補を絞る＋高速化
- 写真の18〜21時抽出後に、読み取り専用の端末内サムネイルを64×48へ縮小して色を判定。茶〜オレンジのお盆らしい写真を候補として優先表示し、未一致も確認可能。
- RGB色・画像内の分布による簡易推定です。専用の学習済み画像認識モデルではないため、照明や背景により誤判定します。
- Androidでサムネイル提供用エンドポイント(`/thumb/<ID>`)を追加し、大きな原本を候補表示で読み込まない方式へ変更。
- 写真登録時の画像デコードを2回→1回、登録用画像1600px・サムネイル360pxへ最適化。登録数の進捗と所要時間を表示。
- 元写真・既存のカレンダー記録は変更・削除しません。

## v0.2.5 APKビルド方式の修正とアプリ内更新
- Android Gradle Plugin 8.7.3＋Android SDK 35による正規ビルド。手書きDEXビルダーによるAPK生成は使用しない。
- 更新ボタンはAndroidのDownloadManagerでAPKを自動ダウンロードし、完了時にFileProviderでAndroidのパッケージインストーラへ渡す。
- Androidの「この提供元を許可」を求められた場合はOSの設定画面を表示する。権限を与えた後、インストール確認画面に進む。
- アプリ内DBは既存と同じWebViewのoriginで保存。packageIdを維持。同じ署名鍵で配布しない限り上書き更新不可。
- 自動ダウンロード先はGitHub公開リポジトリの同一固定URL。


## v0.2.6 Calendar Photo Detail
- Tap a day to see each photo at the full available width, at its original aspect ratio.
- Edit and delete buttons remain below the large photo. Tap a photo for immersive viewing.
- Full-resolution image blobs are loaded on demand; their object URLs are revoked when the day dialog closes.
- Package id unchanged (`jp.osakakon.dinnerphotolog`), versionCode 8, for an in-place update.
