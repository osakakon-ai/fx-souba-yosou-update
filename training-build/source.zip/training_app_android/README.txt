筋トレログ Android版 v0.1.0

このフォルダはAndroid Studio/Gradle用のAPKビルドプロジェクトです。
アプリID: jp.osakakon.traininglog
最低Android: Android 10 (API 29)
対象Android: API 35

主な機能:
- ダークUI
- カレンダー記録
- 筋トレメニュー登録
- 複数選択・順番変更
- セット進行と休憩タイマー
- 完了記録
- 共有画像の生成
- Android共有画面からXへ共有
- 画像を写真へ保存
- ステータスバー回避
- ホーム画面アイコン
- 右上の更新ボタン

ビルドにはAndroid SDKとGradle/Android Studioが必要です。
